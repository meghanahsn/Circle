'''
Author: Meghana Hassan Sridhara 19483342

Pledge of Honour: I pledge by honour that this program is solely my own work

Description: This program is to calculate Area and Perimeter of the circle. 
'''
# create a variable and read from user for the radius value
radius = float(input("Enter a radius "))
# create a variable and assign PIE value 
PI = 3.14
# calculating area by formula
area = PI * (radius*radius)
# calculating perimeter by formula
perimeter = 2 * PI * radius
# print value of calculated perimeter with 2 decimal value
print("Perimeter", round(perimeter,2))
# print value of calculated area with 2 decimal value
print("Area",round(area,2))