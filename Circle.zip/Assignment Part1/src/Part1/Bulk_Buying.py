'''
Author: Meghana Hassan Sridhara 19483342

Pledge of Honour: I pledge by honour that this program is solely my own work

Description: This program is to Determine bulk-buying discount.
'''
# create a variable and read from user for the product price
prod_price = int(input("Enter product price :$"))
# create a variable and read from user for the product quantity
quantity = int(input("Enter quantity: "))
# create a variable and read from user either they claimed discount or not 
claimDiscount = input("Have you claimed the discount before:")
# if user not claimed the discount them check for eligibility
while(claimDiscount == "n") and (prod_price > 0 and prod_price <= 50) and  (quantity > 0 and quantity <=10 ):
    # display Qualified message
    print("You qualify the discount")
    break
else:
        # display dis-qualified message
    print("Sorry, you don't qualify the discount")