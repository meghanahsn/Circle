'''
Author: Meghana Hassan Sridhara 19483342

Pledge of Honour: I pledge by honour that this program is solely my own work

Description: Extend the program to perform user input checking on.
'''
# create a variable and read from user for the product price
prod_price = int(input("Enter product price :$"))
# check for product price is valid or not
while(prod_price <= 0):
    # display message for invalid product price
    print("Invalid input. Product price must be greater than zero.")
    # Allow user to enter Product price again if invalid
    prod_price = int(input("Enter product price :$"))
else:
    # create a variable and read from user for the product quantity
    quantity = int(input("Enter quantity: "))
    # check for product quantity is valid or not
    while(quantity <= 2 or quantity > 10):
        # display message for invalid product price
        print("Invalid input. Quantity must be 2-10 inclusive.")
        # Allow user to enter Product price again if invalid
        quantity = int(input("Enter quantity: "))
    else: 
        # create a variable and read from user either they are eligible to claimed discount or not
        claimDiscount = input("Have you claimed the discount before:")
        # check for correct input for claim discount
        while(claimDiscount !="y") and (claimDiscount !="n"):
            # display message for invalid input for claim discount
            print("Invalid input. Response must be either y or n.")
            # Allow user to enter Claim discount again if invalid
            claimDiscount = input("Have you claimed the discount before:")
        else:
            # check user is not eligible to claim discount 
            while(claimDiscount == "y"):
                # display disqualified message
                print("Sorry, you don\'t qualify the discount")
                break
            else:
                # check user is eligible to claim discount 
                while(claimDiscount == "n"): 
                    # display Qualified message
                    print("You qualify the discount")
                    break
