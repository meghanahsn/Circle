'''
Author: Meghana Hassan Sridhara 19483342

Pledge of Honour: I pledge by honour that this program is solely my own work

Description: This program is to display  Message of the day.
'''
# create a variable and read from user to enter a number
i = int(input("enter a number"))
# determine and print week days based on user input 
if i == 1:
    print("Dizzy Monday")
elif i == 2:
    print("Violent Tuesday")
elif i == 3:
    print("Weedy Wednesday")
elif i == 4:
    print("Shiny Thursday")
elif i == 5:
    print("Good Friday")
elif i == 6:
    print("Relaxing Saturday")
elif i == 7:
    print("Crazy Sunday")
else:
    print("Mysterious Day")
